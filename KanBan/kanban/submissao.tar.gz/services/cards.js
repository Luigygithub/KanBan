import { getOneCard } from "../data/cards";

export async function getCard(id){
    return await getOneCard(id)
}