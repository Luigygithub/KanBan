// export default function handler(req, res) {
//     if (req.method === "GET") { 
//         const status = req.query.status

//         // Chamar o serviço
//     }
//     res.status(200).json({ name: 'John Doe' })
//   }
  